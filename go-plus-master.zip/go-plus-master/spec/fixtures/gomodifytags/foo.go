package foo

type Bar struct {
	QuickBrownFox int
	LazyDog       string
}
