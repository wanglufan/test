package main

import "fmt"

var foo = "Hello, World"

func main() {
	fmt.Println(foo)
}
