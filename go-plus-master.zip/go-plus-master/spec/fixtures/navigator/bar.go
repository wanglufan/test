package foo

func Bar() string {
  return "bar"
}
