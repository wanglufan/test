package foo

func Foo() string {
  return "Foo" + Bar()
}
